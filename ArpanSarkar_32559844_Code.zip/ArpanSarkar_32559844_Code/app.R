library(semantic.dashboard)
library(tidyverse)
library(gganimate)
library(countrycode)
library(ggplot2)
library(viridis)
library(lubridate)
library(shinydashboard)
library(shiny)
library(shinycssloaders)
library(highcharter)
library(plotly)
library(janitor)
library(babynames)
library(hrbrthemes)

ui = dashboardPage(skin = 'purple',
  title = 'GSC',
  header = dashboardHeader(
    titleWidth='100%',
    title = span(
      tags$img(src="stock.jpg",width = '100%'), 
      column(12, class="title-box", 
             tags$h1(class="primary-title", style='margin-top:5px;', 'Interactive Narrative Visualization of Global Supply Chain Data'), 
             tags$h2(class="primary-subtitle", style='margin-top:5px;', ''))),
    dropdownMenuOutput("helpMenu")       
  ),
  dashboardSidebar(
    sidebarMenu(
      menuItem("Panel1",
               tabName = "Vis1",
               icon = icon("dashboard")),
      menuItem("Panel2",
               tabName = "Vis2",
               icon = icon("th"))
    )
  ),
  
  dashboardBody(
    #reference(https://www.w3schools.com/howto/howto_css_responsive_header.asp)
    tags$style(type="text/css", "
/*    Move everything below the header */
    .content-wrapper {
        margin-top: 50px;
    }
    .content {
        padding-top: 60px;
    }
/*    Format the title/subtitle text */
    .title-box {
        position: absolute;
        text-align: center;
        top: 50%;
        left: 50%;
        transform:translate(-50%, -50%);
    }
    @media (max-width: 590px) {
        .title-box {
            position: absolute;
            text-align: center;
            top: 10%;
            left: 10%;
            transform:translate(-5%, -5%);
        }
    }
    @media (max-width: 767px) {
        .primary-title {
            font-size: 1.1em;
        }
        .primary-subtitle {
            font-size: 1em;
        }
    }
/*    Make the image taller */
    .main-header .logo {
        height: 125px;
    }
/*    Override the default media-specific settings */
    @media (max-width: 5000px) {
        .main-header {
            padding: 0 0;
            position: relative;
        }
        .main-header .logo,
        .main-header .navbar {
            width: 100%;
            float: none;
        }
        .main-header .navbar {
            margin: 0;
        }
        .main-header .navbar-custom-menu {
            float: right;
        }
    }
/*    Move the sidebar down */
    .main-sidebar {
        position: absolute;
    }
    .left-side, .main-sidebar {
        padding-top: 175px;
    }"
    ),
    tabItems(
      tabItem(tabName = "Vis1",fluidRow(
              box(imageOutput('bar', height = 545),HTML("<p>It may be said that 
variation of profits across continents as well as across months are mostly varied.</p><ul>
<li> On X-axis months as 1, 2 etc shown. </li>
<li> On Y-axis consolidated profit grouped by months are shown. </li>
<li> Line diagrams of different colours represent different continents. </li>
<li> Line diagrams move within the plot area dynamically. </li>
<li> This is Automated Interactive Line Chart visualisation. </li>
</ul>")),
              box(plotlyOutput('bar1'),HTML("<p>The facet plot speaks about region wise yearly profit for the interactive department. The outcome of the view may be summarized as: profit is not distributed evenly neither for the years nor for the regions.</p><ul>
<li> on X-axis years are shown. </li>
<li> on Y-axis Profit values are shown. </li>
<li> Facet of Histograms are shown in the region boxes. </li>
<li> Departments of export goods are provided with drop down option. </li>
<li> Tool tips used to show details on placing cursor over the area. </li>
</ul>")),
              box(selectInput(inputId = "Department",label = "Department",
                              list("Apparel", "Discs Shop", "Fan Shop", "Fitness", "Footwear","Golf","Health and Beauty","Outdoors", "Pet Shop","Technology"),
                              multiple = F, selected = "Apparel")))),
      tabItem(tabName = "Vis2",
                box(highchartOutput(height =522,"hc1"),HTML("<p>The choropleth map view speaks clearly that countries have different accumulated profit and a scope for competition prevails.</p><ul>
<li> A map of the Globe with countries marked in defalt colors displayed. </li>
<li> Profit range shown with color with varied density. </li>
<li> Cursor is the tool for interaction within the plot. </li>
<li> Colour of the country changes automatically according to profit range. </li>
<li> Tool tip provided to now the detail in figure where placed. </li>
</ul>")),
                box(plotlyOutput('bar2'),HTML("<p>The density plot makes it clear that most shipment happens through standard class as it is cost effective and its efficiency level is higher than others.</p><ul>
<li> on X-axis profit figures are shown.</li>
<li> on Y-axis density is shown. </li>
<li> Shipping mode provided with Drop down option for user interaction. </li>
<li> Moving the cursor over any area in the plot gives detail data for that area. </li>
<li> Comparison of different shipping modes mae easy. </li>
</ul>")),
                box(selectInput(inputId = "Shipping_Mode",
                                label = "Shipping_Mode",
                                list("Standard Class","First Class", "Second Class", "Same Day"),
                                multiple = F, selected = "Standard Class")),fluidRow(box(width = 12, highchartOutput("hc2",width =1000),HTML("<p>From this scatter plot view we can infer that most of the profits are shared by Americas and Europe, while for Asia it is found that average price is very high while profit is less.</p><ul>
<li> on X-axis benefits are shown.</li>
<li> on Y-axis Average-Price are shown.</li>
<li> Continents are marked with different colours.</li>
<li> Choosing one continent, effects change of colour in the plot area. </li>
<li> Further interaction effected by moving cursor to see details in tool tip box.</li>
</ul>"))))
    
    
  )  
)
)







# Define server logic 
server <- function(input, output, session) {
  supply<- read_csv("data/supply.csv")
  supply$continent <- countrycode(sourcevar = supply$Order.Country,
                                  origin = "country.name",
                                  destination = "continent")
  supply$iso3<-countrycode(sourcevar = supply$Order.Country,
                           origin = "country.name",
                           destination = "iso3c")
  supply$Year<- year(supply$Date)
  supply$Month<- month(supply$Date)
  df3<-supply%>%select(Benefit.per.order,continent,Month,Order.Item.Product.Price,Year,Order.Region)%>%group_by(Month,continent)%>%summarise(avg_benefit= mean(Benefit.per.order,na.rm=T), avg_price= mean(Order.Item.Product.Price))
  df5<-supply%>%select(Benefit.per.order,continent,Month,Year,Order.Region,Department.Name,Shipping.Mode,Order.Item.Product.Price)%>%group_by(Year,continent,Department.Name,Order.Region,Shipping.Mode)%>%summarise(Tot_benefit= sum(Benefit.per.order,na.rm=T), Avg_price=mean(Order.Item.Product.Price,na.rm=T))
  df6<-supply%>%select(Benefit.per.order,continent,Month,Year,Order.Region,Department.Name,Shipping.Mode)%>%group_by(Year,continent,Department.Name,Order.Region,Shipping.Mode)%>%summarise(Tot_benefit= sum(Benefit.per.order,na.rm=T))
  data1<- reactive({
    req(input$Department)
    df_5<- df5%>% filter(Department.Name %in% input$Department)
  })
  data2<- reactive({
    req(input$Department)
    df_6<- df6%>% filter(Shipping.Mode %in% input$Shipping_Mode)  
  })
  output$bar1<-renderPlotly({
    
    dd<-ggplot(data1(),aes(x= Year, y= Tot_benefit, fill= input$Department))+
      geom_bar(stat = "identity")+
      ggtitle("Interactive facet plot view:")+
      facet_wrap(~ Order.Region)+
      theme(axis.text.x = element_text(angle = 70))+
      theme(axis.text.y = element_text(angle = 20))
    ggplotly(dd)
    
  })
  output$bar2<-renderPlotly({
    
    ww<-ggplot(data2(),aes(x=Tot_benefit, color= input$Shipping_Mode 
                           , fill= input$Shipping_Mode ))+
      geom_density(alpha=0.3, size=1)+
      ggtitle("Interactive Density plot view:")+
      scale_x_log10()
    ggplotly(ww)
  })
  output$hc1<-renderHighchart({
    
    dftt<-supply%>%select(Benefit.per.order,continent,Month,Order.Item.Product.Price,Category.Name,Order.Region,Department.Name,Shipping.Mode,iso3)%>%group_by(continent,iso3)%>%summarise(Tot_benefit= sum(Benefit.per.order,na.rm=T), avg_price= mean(Order.Item.Product.Price))
    
    dft1<-dftt%>% select(iso3,continent,Tot_benefit,avg_price)
    #reference(https://jkunst.com/highcharter/)
    hcmap(
      "custom/world-robinson-lowres", 
      data = dft1,
      name = "Profit Value",
      value = "Tot_benefit",
      borderWidth = 0,
      nullColor = "#d3d3d3",
      joinBy = c("iso-a3", "iso3")
    ) %>%
      hc_colorAxis(
        stops = color_stops(colors = viridisLite::inferno(10, begin = 0.1)),
        type = "logarithmic"
      )%>%
      hc_title(
        text = "Interactive Choropleth Map view:",
        margin = 20,
        align = "left",
        style = list(color = "#000000", useHTML = TRUE)
      )
  })  
  #reference(https://jkunst.com/highcharter/)
  output$hc2<-renderHighchart({
    hchart(df5, 'scatter', hcaes(x=Tot_benefit,y=Avg_price, group=continent))%>%
      hc_title(
        text = "Interactive Scatter Plot view:",
        margin = 20,
        align = "left",
        style = list(color = "#000000", useHTML = TRUE)
      )
  }) 
  #reference(https://shiny.rstudio.com/articles/images.html)
  output$bar<- renderImage({
    outfile<- tempfile(fileext = '.gif')
    
    p= ggplot(df3, aes(x= Month, y=avg_benefit, group=continent, color=continent)) +
      geom_line(aes(size= 0.5),show.legend = F) +
      geom_point(aes(size= 0.7)) +
      scale_x_continuous(breaks = 0:12)+
      ggtitle("Profit by continents consolidated to months.") +
      scale_color_viridis_d()+
      theme_ipsum() +
      ylab("avg_benefit") +
      transition_reveal(Month)
    
    anim_save("outfile.gif", animate(p))
    
    list(src = "outfile.gif",
         contentType = 'image/gif'
        
    )}, deleteFile = TRUE,)}
# Create Shiny app ----
shinyApp(ui = ui, server = server)